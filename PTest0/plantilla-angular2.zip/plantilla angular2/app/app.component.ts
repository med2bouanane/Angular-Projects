import { Component} from '@angular/core';

@Component({
  selector: 'mi-aplicacion',
  template: '<h1>Aprende Angular 2 Fácilmente</h1>'    
})

export class AppComponent  { 
}
